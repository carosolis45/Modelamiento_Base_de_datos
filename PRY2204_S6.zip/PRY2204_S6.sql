
CREATE TABLE COMUNA(
id_comuna NUMBER (10) PRIMARY KEY,
nombre_comuna VARCHAR2 (50) NOT NULL,
region VARCHAR2 (120) NOT NULL
);

CREATE TABLE ESPECIALIDAD (
id_especialidad NUMBER (10) PRIMARY KEY,
nombre_especialidad VARCHAR2 (120) NOT NULL,
descripcion VARCHAR2 (200)
);

DROP TABLE ESPECIALIDAD;
DROP TABLE PACIENTE;
DROP TABLE COMUNA;
DROP TABLE ESPECIALIDAD;

CREATE TABLE REGION (
    id_region NUMBER PRIMARY KEY,
    nombre_region VARCHAR2(100) NOT NULL
);

CREATE TABLE CIUDAD (
    id_ciudad NUMBER PRIMARY KEY,
    nombre_ciudad VARCHAR2(100) NOT NULL,
    id_region NUMBER NOT NULL,
    CONSTRAINT fk_ciudad_region FOREIGN KEY (id_region) REFERENCES REGION(id_region)
);

-- Tabla COMUNA (con identity comenzando en 1101)
CREATE TABLE COMUNA (
    id_comuna NUMBER GENERATED ALWAYS AS IDENTITY (START WITH 1101 INCREMENT BY 1) PRIMARY KEY,
    nombre_comuna VARCHAR2(100) NOT NULL,
    id_ciudad NUMBER NOT NULL,
    CONSTRAINT fk_comuna_ciudad FOREIGN KEY (id_ciudad) REFERENCES CIUDAD(id_ciudad)
);

CREATE TABLE PACIENTE (
    id_paciente NUMBER PRIMARY KEY,
    rut VARCHAR2(12) NOT NULL,
    digito_verificador VARCHAR2(1) NOT NULL CHECK (digito_verificador IN ('0','1','2','3','4','5','6','7','8','9','K')),
    nombre VARCHAR2(100) NOT NULL,
    apellido VARCHAR2(100) NOT NULL,
    edad NUMBER,
    direccion VARCHAR2(200) NOT NULL,
    id_comuna NUMBER NOT NULL,
    CONSTRAINT fk_paciente_comuna FOREIGN KEY (id_comuna) REFERENCES COMUNA(id_comuna),
    CONSTRAINT uk_paciente_rut UNIQUE (rut, digito_verificador)
);

CREATE TABLE DIGITADOR (
    id_digitador NUMBER PRIMARY KEY,
    rut VARCHAR2(12) NOT NULL,
    digito_verificador VARCHAR2(1) NOT NULL CHECK (digito_verificador IN ('0','1','2','3','4','5','6','7','8','9','K')),
    nombre VARCHAR2(100) NOT NULL,
    apellido VARCHAR2(100) NOT NULL,
    CONSTRAINT uk_digitador_rut UNIQUE (rut, digito_verificador)
);

CREATE TABLE ESPECIALIDAD (
    id_especialidad NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre_especialidad VARCHAR2(100) NOT NULL
);

CREATE TABLE MEDICO (
    id_medico NUMBER PRIMARY KEY,
    rut VARCHAR2(12) NOT NULL,
    digito_verificador VARCHAR2(1) NOT NULL CHECK (digito_verificador IN ('0','1','2','3','4','5','6','7','8','9','K')),
    nombre VARCHAR2(100) NOT NULL,
    apellido VARCHAR2(100) NOT NULL,
    telefono VARCHAR2(20) NOT NULL UNIQUE, -- Tel�fono �nico
    id_especialidad NUMBER NOT NULL,
    CONSTRAINT fk_medico_especialidad FOREIGN KEY (id_especialidad) REFERENCES ESPECIALIDAD(id_especialidad),
    CONSTRAINT uk_medico_rut UNIQUE (rut, digito_verificador)
);

CREATE TABLE TIPO_RECETA (
    id_tipo_receta NUMBER PRIMARY KEY,
    nombre_tipo VARCHAR2(50) NOT NULL
);

CREATE TABLE TIPO_MEDICAMENTO (
    id_tipo_medicamento NUMBER PRIMARY KEY,
    nombre_tipo VARCHAR2(50) NOT NULL
);

CREATE TABLE MEDICAMENTO (
    id_medicamento NUMBER PRIMARY KEY,
    nombre VARCHAR2(100) NOT NULL,
    dosis_recomendada VARCHAR2(100),
    stock_disponible NUMBER DEFAULT 0,
    id_tipo_medicamento NUMBER NOT NULL,
    CONSTRAINT fk_medicamento_tipo FOREIGN KEY (id_tipo_medicamento) REFERENCES TIPO_MEDICAMENTO(id_tipo_medicamento)
);

CREATE TABLE RECETA (
    id_receta NUMBER PRIMARY KEY,
    fecha_emision DATE NOT NULL,
    observaciones CLOB,
    fecha_expiracion DATE,
    id_paciente NUMBER NOT NULL,
    id_medico NUMBER NOT NULL,
    id_digitador NUMBER NOT NULL,
    id_tipo_receta NUMBER NOT NULL,
    CONSTRAINT fk_receta_paciente FOREIGN KEY (id_paciente) REFERENCES PACIENTE(id_paciente),
    CONSTRAINT fk_receta_medico FOREIGN KEY (id_medico) REFERENCES MEDICO(id_medico),
    CONSTRAINT fk_receta_digitador FOREIGN KEY (id_digitador) REFERENCES DIGITADOR(id_digitador),
    CONSTRAINT fk_receta_tipo FOREIGN KEY (id_tipo_receta) REFERENCES TIPO_RECETA(id_tipo_receta)
);

CREATE TABLE DETALLE_RECETA (
    id_detalle NUMBER PRIMARY KEY,
    id_receta NUMBER NOT NULL,
    id_medicamento NUMBER NOT NULL,
    cantidad NUMBER NOT NULL CHECK (cantidad > 0),
    CONSTRAINT fk_detalle_receta FOREIGN KEY (id_receta) REFERENCES RECETA(id_receta),
    CONSTRAINT fk_detalle_medicamento FOREIGN KEY (id_medicamento) REFERENCES MEDICAMENTO(id_medicamento),
    CONSTRAINT uk_detalle_receta_medicamento UNIQUE (id_receta, id_medicamento)
);

CREATE TABLE PAGO (
    id_pago NUMBER PRIMARY KEY,
    monto_pagado NUMBER(12,2) NOT NULL CHECK (monto_pagado >= 0),
    fecha_pago DATE NOT NULL,
    id_receta NUMBER NOT NULL,
    CONSTRAINT fk_pago_receta FOREIGN KEY (id_receta) REFERENCES RECETA(id_receta)
);

-- Agregar precio unitario a medicamento con restricci�n 
ALTER TABLE MEDICAMENTO 
ADD precio_unitario NUMBER(12,2) 
CHECK (precio_unitario BETWEEN 1000 AND 2000000);

-- Agregar m�todo de pago 
ALTER TABLE PAGO 
ADD metodo_pago VARCHAR2(20) 
CHECK (metodo_pago IN ('EFECTIVO', 'TARJETA', 'TRANSFERENCIA'));

-- Eliminar columna edad y agregar fecha de nacimiento en paciente
ALTER TABLE PACIENTE 
DROP COLUMN edad;

ALTER TABLE PACIENTE 
ADD fecha_nacimiento DATE;















 
 
 





