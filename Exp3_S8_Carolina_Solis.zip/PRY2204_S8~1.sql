CREATE TABLE region (
    id_region NUMBER(4) PRIMARY KEY,
    nom_region VARCHAR2(255) NOT NULL
);

CREATE TABLE afp (
    id_afp NUMBER(5) GENERATED ALWAYS AS IDENTITY (START WITH 210 INCREMENT BY 6) PRIMARY KEY,
    nom_afp VARCHAR2(255) NOT NULL
);

CREATE TABLE salud (
    id_salud NUMBER(4) PRIMARY KEY,
    nom_salud VARCHAR2(40) NOT NULL
);

CREATE TABLE marca (
    id_marca NUMBER(3) PRIMARY KEY,
    nombre_marca VARCHAR2(255) NOT NULL,
    CONSTRAINT marca_nombre_unique UNIQUE (nombre_marca)
);

CREATE TABLE categoria (
    id_categoria NUMBER(3) PRIMARY KEY,
    nombre_categoria VARCHAR2(255) NOT NULL
);

CREATE TABLE medio_pago (
    id_mpago NUMBER(3) PRIMARY KEY,
    nombre_mpago VARCHAR2(60) NOT NULL
);

-- Tablas con dependencias
CREATE TABLE comuna (
    id_comuna NUMBER(4) PRIMARY KEY,
    nom_comuna VARCHAR2(100) NOT NULL,
    cod_region NUMBER(4) NOT NULL,
    CONSTRAINT comuna_region_fk FOREIGN KEY (cod_region) REFERENCES region(id_region)
);

CREATE TABLE proveedor (
    id_proveedor NUMBER(5) PRIMARY KEY,
    nombre_proveedor VARCHAR2(150) NOT NULL,
    rut_proveedor VARCHAR2(10) NOT NULL,
    telefono VARCHAR2(10),
    email VARCHAR2(200),
    direccion VARCHAR2(200),
    cod_comuna NUMBER(4) NOT NULL,
    CONSTRAINT proveedor_email_unique UNIQUE (email),
    CONSTRAINT proveedor_comuna_fk FOREIGN KEY (cod_comuna) REFERENCES comuna(id_comuna)
);

CREATE TABLE empleado (
    id_empleado NUMBER(4) PRIMARY KEY,
    rut_empleado VARCHAR2(10) NOT NULL,
    nombre_empleado VARCHAR2(25) NOT NULL,
    apellido_paterno VARCHAR2(20) NOT NULL,
    apellido_materno VARCHAR2(25) NOT NULL,
    fecha_contratacion DATE NOT NULL,
    sueldo_base NUMBER(10) NOT NULL CHECK (sueldo_base >= 400000),
    bono_jefatura NUMBER(10),
    activo CHAR(1) CHECK (activo IN ('S', 'N')),
    tipo_empleado VARCHAR2(25) NOT NULL,
    cod_jefe NUMBER(4),
    cod_salud NUMBER(4) NOT NULL,
    cod_afp NUMBER(5) NOT NULL,
    CONSTRAINT empleado_salud_fk FOREIGN KEY (cod_salud) REFERENCES salud(id_salud),
    CONSTRAINT empleado_afp_fk FOREIGN KEY (cod_afp) REFERENCES afp(id_afp),
    CONSTRAINT empleado_jefe_fk FOREIGN KEY (cod_jefe) REFERENCES empleado(id_empleado)
);

CREATE TABLE producto (
    id_producto NUMBER(4) PRIMARY KEY,
    nombre_producto VARCHAR2(100) NOT NULL,
    precio_unitario NUMBER NOT NULL CHECK (precio_unitario > 0),
    origen_id CHAR(1) CHECK (origen_id IN ('N', 'I')),
    stock_minimo NUMBER(3) NOT NULL CHECK (stock_minimo >= 3),
    status_id CHAR(1) CHECK (status_id IN ('A', 'I')),
    cod_marca NUMBER(3) NOT NULL,
    cod_categoria NUMBER(3) NOT NULL,
    cod_proveedor NUMBER(5) NOT NULL,
    CONSTRAINT producto_marca_fk FOREIGN KEY (cod_marca) REFERENCES marca(id_marca),
    CONSTRAINT producto_categoria_fk FOREIGN KEY (cod_categoria) REFERENCES categoria(id_categoria),
    CONSTRAINT producto_proveedor_fk FOREIGN KEY (cod_proveedor) REFERENCES proveedor(id_proveedor)
);

CREATE TABLE vendedor (
    id_empleado NUMBER(4) PRIMARY KEY,
    comision_ventas NUMBER(2,2) NOT NULL CHECK (comision_ventas BETWEEN 0 AND 0.25),
    CONSTRAINT vendedor_empleado_fk FOREIGN KEY (id_empleado) REFERENCES empleado(id_empleado)
);

CREATE TABLE administrativo (
    id_empleado NUMBER(4) PRIMARY KEY,
    CONSTRAINT administrativo_empleado_fk FOREIGN KEY (id_empleado) REFERENCES empleado(id_empleado)
);

CREATE TABLE venta (
    id_venta NUMBER(4) GENERATED ALWAYS AS IDENTITY (START WITH 5050 INCREMENT BY 3) PRIMARY KEY,
    fecha_venta DATE NOT NULL,
    total_venta NUMBER(10) NOT NULL CHECK (total_venta > 0),
    cod_mpago NUMBER(3) NOT NULL,
    cod_empleado NUMBER(4) NOT NULL,
    CONSTRAINT venta_medio_pago_fk FOREIGN KEY (cod_mpago) REFERENCES medio_pago(id_mpago),
    CONSTRAINT venta_empleado_fk FOREIGN KEY (cod_empleado) REFERENCES empleado(id_empleado)
);

CREATE TABLE detalle_venta (
    cod_venta NUMBER(4),
    cod_producto NUMBER(4),
    cantidad NUMBER(6) NOT NULL CHECK (cantidad > 0),
    CONSTRAINT detalle_venta_pk PRIMARY KEY (cod_venta, cod_producto),
    CONSTRAINT det_venta_venta_fk FOREIGN KEY (cod_venta) REFERENCES venta(id_venta),
    CONSTRAINT det_venta_producto_fk FOREIGN KEY (cod_producto) REFERENCES producto(id_producto)
);

CREATE SEQUENCE seq_salud
START WITH 2050
INCREMENT BY 10
NOCACHE
NOCYCLE;

CREATE SEQUENCE seq_empleado
START WITH 750
INCREMENT BY 3
NOCACHE
NOCYCLE;

-- vamos a poblar la tabla salud
INSERT INTO salud (id_salud, nom_salud) VALUES (seq_salud.NEXTVAL, 'Fonasa');
INSERT INTO salud (id_salud, nom_salud) VALUES (seq_salud.NEXTVAL, 'Banm�dica');
INSERT INTO salud (id_salud, nom_salud) VALUES (seq_salud.NEXTVAL, 'Colmena');
INSERT INTO salud (id_salud, nom_salud) VALUES (seq_salud.NEXTVAL, 'Consalud');

-- vamos a Poblar la tabla AFP
INSERT INTO afp (nom_afp) VALUES ('Habitat');
INSERT INTO afp (nom_afp) VALUES ('Cuprum');
INSERT INTO afp (nom_afp) VALUES ('Provida');
INSERT INTO afp (nom_afp) VALUES ('Planvital');

-- vamos a Poblar la tabla MEDIO_PAGO
INSERT INTO medio_pago (id_mpago, nombre_mpago) VALUES (1, 'Efectivo');
INSERT INTO medio_pago (id_mpago, nombre_mpago) VALUES (2, 'Tarjeta D�bito');
INSERT INTO medio_pago (id_mpago, nombre_mpago) VALUES (3, 'Tarjeta Cr�dito');
INSERT INTO medio_pago (id_mpago, nombre_mpago) VALUES (4, 'Cheque');

-- vamos a Poblar la tabla REGION
INSERT INTO region (id_region, nom_region) VALUES (1, 'Metropolitana');
INSERT INTO region (id_region, nom_region) VALUES (2, 'Valpara�so');
INSERT INTO region (id_region, nom_region) VALUES (3, 'Biob�o');
INSERT INTO region (id_region, nom_region) VALUES (4, 'Los Lagos');

-- vamos a Poblar tabla EMPLEADO
INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '32111111-1', 'Marcela', 'Gonz�lez', 'P�rez', TO_DATE('15-03-2022', 'DD-MM-YYYY'), 950000, 50000, 'S', 'Administrativo', NULL, 2050, 210);

INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '22222222-2', 'Jos�', 'Mu�oz', 'Ram�rez', TO_DATE('10-07-2021', 'DD-MM-YYYY'), 980000, 75000, 'S', 'Administrativo', NULL, 2060, 216);

INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '33333333-3', 'Ver�nica', 'Soto', 'Alarc�n', TO_DATE('05-01-2023', 'DD-MM-YYYY'), 880000, 70000, 'S', 'Vendedor', 738, 2060, 222);

INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '33333333-3', 'Ver�nica', 'Soto', 'Alarc�n', TO_DATE('05-01-2023', 'DD-MM-YYYY'), 880000, 70000, 'S', 'Vendedor', 738, 2060, 222);


SELECT * FROM empleado WHERE rut_empleado = '33333333-3';

SELECT id_empleado, rut_empleado, nombre_empleado 
FROM empleado 
WHERE rut_empleado = '33333333-3';

INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '33333333-3', 'Ver�nica', 'Soto', 'Alarc�n', TO_DATE('05-01-2023', 'DD-MM-YYYY'), 880000, 70000, 'S', 'Vendedor', 738, 2060, 222);

INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '33333333-3', 'Ver�nica', 'Soto', 'Alarc�n', TO_DATE('05-01-2023', 'DD-MM-YYYY'), 880000, 70000, 'S', 'Vendedor', 738, 2060, 222);

SELECT id_empleado, rut_empleado, nombre_empleado
FROM empleado 
WHERE rut_empleado = '33333333-3';

SELECT id_empleado, nombre_empleado 
FROM empleado 
WHERE id_empleado = 738;

SELECT id_empleado, nombre_empleado 
FROM empleado 
WHERE tipo_empleado = 'Jefe' OR tipo_empleado = 'Gerente';

INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '33333333-3', 'Ver�nica', 'Soto', 'Alarc�n', TO_DATE('05-01-2023', 'DD-MM-YYYY'), 880000, 70000, 'S', 'Vendedor', NULL, 2060, 222);

-- vamos a Poblar la  tabla VENDEDOR
INSERT INTO vendedor (id_empleado, comision_ventas) VALUES (756, 0.15);

SELECT id_empleado, nombre_empleado, apellido_paterno, tipo_empleado 
FROM empleado 
WHERE tipo_empleado = 'Vendedor';

INSERT INTO vendedor (id_empleado, comision_ventas) VALUES (759, 0.12);

SELECT id_empleado, nombre_empleado, apellido_paterno, tipo_empleado 
FROM empleado 
WHERE tipo_empleado = 'Vendedor';

INSERT INTO vendedor (id_empleado, comision_ventas) VALUES (765, 0.15);

INSERT INTO vendedor (id_empleado, comision_ventas) VALUES (753, 0.12);  
INSERT INTO vendedor (id_empleado, comision_ventas) VALUES (750, 0.10);  

-- Poblar tabla VENTA
INSERT INTO venta (fecha_venta, total_venta, cod_mpago, cod_empleado) 
VALUES (TO_DATE('12-05-2023', 'DD-MM-YYYY'), 225990, 1, 765);

INSERT INTO venta (fecha_venta, total_venta, cod_mpago, cod_empleado) 
VALUES (TO_DATE('23-10-2023', 'DD-MM-YYYY'), 524990, 3, 753);

INSERT INTO venta (fecha_venta, total_venta, cod_mpago, cod_empleado) 
VALUES (TO_DATE('21-02-2023', 'DD-MM-YYYY'), 466590, 2, 750);

COMMIT;


SELECT 
    id_empleado AS "IDENTIFICADOR",
    nombre_empleado || ' ' || apellido_paterno || ' ' || apellido_materno AS "NOMBRE COMPLETO",
    sueldo_base AS "SALARIO",
    bono_jefatura AS "BONIFICACION",
    (sueldo_base + NVL(bono_jefatura, 0)) AS "SALARIO SIMULADO"
FROM empleado
WHERE activo = 'S' 
    AND bono_jefatura IS NOT NULL
    AND bono_jefatura > 0
ORDER BY "SALARIO SIMULADO" DESC, apellido_paterno DESC;

SELECT 
    nombre_empleado || ' ' || apellido_paterno || ' ' || apellido_materno AS "EMPLEADO",
    sueldo_base AS "SUELDO",
    (sueldo_base * 0.08) AS "POSIBLE AUMENTO",
    (sueldo_base * 1.08) AS "SUELDO SIMULADO"
FROM empleado
WHERE sueldo_base BETWEEN 550000 AND 800000
    AND activo = 'S'
ORDER BY sueldo_base ASC;

SELECT nombre_empleado, sueldo_base, activo
FROM empleado
ORDER BY sueldo_base;

INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '11111111-1', 'Luis', 'Reyes', 'Fuentes', TO_DATE('15-03-2022', 'DD-MM-YYYY'), 560000, 0, 'S', 'Vendedor', NULL, 2060, 222);

INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '22222222-2', 'Fernanda', 'Salas', 'Herrera', TO_DATE('20-04-2022', 'DD-MM-YYYY'), 570000, 0, 'S', 'Vendedor', NULL, 2060, 222);

INSERT INTO empleado (id_empleado, rut_empleado, nombre_empleado, apellido_paterno, apellido_materno, fecha_contratacion, sueldo_base, bono_jefatura, activo, tipo_empleado, cod_jefe, cod_salud, cod_afp) 
VALUES (seq_empleado.NEXTVAL, '33333333-3', 'Claudia', 'Fern�ndez', 'Lagos', TO_DATE('10-05-2022', 'DD-MM-YYYY'), 600000, 0, 'S', 'Vendedor', NULL, 2060, 222);

SELECT
    nombre_empleado || ' ' || apellido_paterno || ' ' || apellido_materno AS "EMPLEADO",
    sueldo_base AS "SUELDO",
    (sueldo_base * 0.08) AS "POSIBLE_AUMENTO",
    (sueldo_base * 1.08) AS "SUELDO_SIMULADO"
FROM empleado
WHERE sueldo_base BETWEEN 550000 AND 800000
    AND activo = 'S'
ORDER BY sueldo_base ASC;
